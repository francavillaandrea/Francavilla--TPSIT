"use strice"

let dim

window.onload = function(){
	
	
	
	
	
}

	



function generaNumero(min, max){
	return Math.floor((max-min)*Math.random() + min)
}
