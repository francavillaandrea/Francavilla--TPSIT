let bookstoreIniziale = `<?xml version="1.0"?> 
<bookstore> 
	<book category="cooking"> 
	    <id> 1 </id>  
		<title lang="en">Everyday Italian</title> 
		<author>Giada De Laurentiis</author> 
		<year>2005</year> 
		<price>30.00</price> 
	</book> 
	<book category="cooking"> 
		<id> 2 </id> 
		<title lang="en">Harry Potter</title> 
		<author>J K. Rowling</author> 
		<price>29.99</price> 
	</book> 
	<book category="web"> 
		<id> 3 </id> 
		<title>XQuery Kick Start</title> 
		<author>James McGovern</author> 
		<author>Per Bothner</author> 
		<author>Kurt Cagle</author> 
		<author>James Linn</author> 
		<author>Vaidyanathan Nagarajan</author> 
		<year>2003</year> 
		<price>49.99</price> 
	</book> 
	<book category="web" cover="paperback"> 
		<id> 4 </id> 
		<title lang="en">Learning XML</title> 
		<author>Erik T. Ray</author> 
		<year>2003</year> 
		<price>39.95</price> 
	</book> 
</bookstore>`