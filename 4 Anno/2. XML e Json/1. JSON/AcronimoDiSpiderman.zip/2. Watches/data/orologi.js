let initialData = `[
    { "gender" : "Men's",
	  "models" : [  {
					 "code"   : "QWZ5671",
					 "price"  : 39.95,
				     "watches"  : [{ "color" : "Red",       "image" : "red_cardigan.jpg"},
					                { "color" : "Burgundy",  "image" : "burgundy_cardigan.jpg"}]
				   },
				   {
					 "code"   : "QWZ5672",
					 "price"  : 45.95,
				     "watches"  : [{ "color" : "Blue",      "image" : "blue_cardigan.jpg"},
					                { "color" : "Burgundy",  "image" : "burgundy_cardigan.jpg"},
									{ "color" : "Black",     "image" : "black_cardigan.jpg"}]
				   },
				   {
					 "code"   : "QWZ5673",
					 "price"  : 60.95,
				     "watches"  : [{ "color" : "Blue",      "image" : "blue_cardigan.jpg"},
					                { "color" : "Black",  "image" : "black_cardigan.jpg"}]
				   }
				]
	},
    { "gender" : "Women's",
	  "models" : [  {
					 "code"   : "RRX9856",
					 "price"  : 42.50,
				     "watches"  : [{ "color" : "Red",       "image" : "red_cardigan.jpg"},
					                { "color" : "Blue",      "image" : "blue_cardigan.jpg"},
					                { "color" : "Burgundy",  "image" : "burgundy_cardigan.jpg"}]
				   },
				   {
					 "code"   : "RRX9857",
					 "price"  : 46.50,
				     "watches"  : [{ "color" : "Red",       "image" : "red_cardigan.jpg"},
					                { "color" : "Blue",      "image" : "blue_cardigan.jpg"},
								    { "color" : "Burgundy",  "image" : "burgundy_cardigan.jpg"},
								    { "color" : "Black",     "image" : "black_cardigan.jpg"}]
				   },
				   {
					 "code"   : "RRX9858",
					 "price"  : 48.50,
				     "watches"  : [ {"color" : "Blue",      "image" : "blue_cardigan.jpg"},
					                { "color" : "Black",     "image" : "black_cardigan.jpg"}]
				   },
				   {
					 "code"   : "RRX9859",
					 "price"  : 55.50,
				     "watches"  : [{ "color" : "Burgundy",  "image" : "burgundy_cardigan.jpg"},
					                { "color" : "Black",     "image" : "black_cardigan.jpg"}]
				   }
				]				   
	}
]`
