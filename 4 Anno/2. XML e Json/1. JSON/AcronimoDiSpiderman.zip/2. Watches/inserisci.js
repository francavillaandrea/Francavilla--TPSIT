"use strict";


let btnSave = document.getElementById("btnSalva")
let btnUndo = document.getElementById("btnAnnulla")
	
let opts = document.getElementsByName("optGender");
let txtCode = document.getElementById("txtCode")
let txtPrice = document.getElementById("txtPrice")
let lstColor = document.getElementById("lstColor")
	


