'use strict'
let form1;

window.onload = function() {
	form1 = document.getElementById("form1")
}

// richiamato dall'html
function visualizza(index) {
	let msg = "";
	let items;
	switch (index) {

	}
	alert(msg);
}


function imposta(index){
	let items	
	switch(index){

	}	 
}

