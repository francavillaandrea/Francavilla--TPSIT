'use strict'

let wrapper;

window.onload = function() {
	wrapper = document.querySelector("#wrapper");
	let buttonsDiv = document.querySelector("#buttons");
	let btns = buttonsDiv.querySelectorAll("input[type=button]");


}