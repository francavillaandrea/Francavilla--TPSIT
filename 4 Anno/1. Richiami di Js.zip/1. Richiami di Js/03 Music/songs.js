const songs = [
    // Id, Name, Author, Album, Duration(s), Gender, Streams
    [1, "m.A.A.d. city", "Kendrick Lamar", "good kid, m.A.A.d. city", 244, "Pop", 12000000],
    [2, "Blinding Lights", "The Weeknd", "After Hours", 200, "Rap", 1500000000],
    [3, "Torcida", "Bresh", "Torcida", 174, "Rap", 5000000],
    [4, "Somebody (2024)", "Gotye & Fisher & Kimbra", "Somebody (2024)", 154, "Rock", 7000000000],
    [5, "2minuti", "Calcutta", "RELAX", 214, "Rap", 34000000],
    [6, "Anime Libere", "Tedua & Rkomi & Bresh", "La divina commedia", 173, "Pop", 28000000],
    [7, "Black Dogs' Old Blues", "I Belli da Vedere", "Cambiare Vita", 164, "Pop", "Veramente troppe"],
    [8, "Aglio e olio", "Fulminacci & Willie Peyote", "Tante care cose e altri successi", 226, "Rap", 5000000],
    [9, "Intro", "The xx", "xx", 128, "Rock", 640000000],
    [10, "LA CANZONE NOSTRA", "MACE & Blanco & Salmo", "OBE", 237, "Rap", 130000000]
];


