// Funzione per aggiornare la posizione del footer in base alla lunghezza della pagina
function updateFooterPosition() {
    const footer = document.getElementById('footer');
    const body = document.body;
    const html = document.documentElement;
    
    // Controlliamo se la pagina è più lunga della finestra
    const pageHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight);
    const windowHeight = window.innerHeight;

    // Se la pagina è più alta della finestra, rimuoviamo la classe .fixed-footer
    if (pageHeight > windowHeight) {
        footer.classList.remove('fixed-footer');
    } else {
        // Se la pagina è più corta della finestra, aggiungiamo la classe .fixed-footer
        footer.classList.add('fixed-footer');
    }
}

// Eseguiamo la funzione all'avvio e ogni volta che la finestra cambia dimensione
window.addEventListener('load', updateFooterPosition);
window.addEventListener('resize', updateFooterPosition);
